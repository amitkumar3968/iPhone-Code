//
//  GridView.m
//  Sudoku
//
//  Created by Warren Moore on 2/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "GridView.h"

@implementation GridView

@synthesize horizontalLineCount, verticalLineCount;

- (id)initWithCoder:(NSCoder *)aDecoder {
	if((self = [super initWithCoder:aDecoder])) {
		verticalLineCount = 2;
		horizontalLineCount = 2;
	}
	return self;
}

- (void)drawRect:(CGRect)rect
{
	CGContextRef context = UIGraphicsGetCurrentContext();
	
	CGFloat horizontalLineSpacing = (NSInteger)(self.bounds.size.width / (self.verticalLineCount + 1));
	
	CGContextSetLineWidth(context, 4);
	
	CGFloat x = horizontalLineSpacing;
	for (int i = 0; i < self.verticalLineCount; ++i) {
		CGContextMoveToPoint(context, x, CGRectGetMinY(self.bounds));
		CGContextAddLineToPoint(context, x, CGRectGetMaxY(self.bounds));
		x += horizontalLineSpacing + 2;
	}
	
	CGContextStrokePath(context);
	
	CGFloat verticalLineSpacing = (NSInteger)(self.bounds.size.width / (self.horizontalLineCount + 1));
	
	CGFloat y = verticalLineSpacing;
	for (int i = 0; i < self.verticalLineCount; ++i) {
		CGContextMoveToPoint(context, CGRectGetMinX(self.bounds), y);
		CGContextAddLineToPoint(context, CGRectGetMaxX(self.bounds), y);
		y += verticalLineSpacing + 2;
	}
	
	CGContextStrokePath(context);
}

@end
