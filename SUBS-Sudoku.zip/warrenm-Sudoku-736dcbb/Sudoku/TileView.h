//
//  TileView.h
//  Sudoku
//
//  Created by Warren Moore on 2/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TileView;

@protocol TileViewDelegate <NSObject>
@required
- (void)valueForTileChanged:(TileView *)view;
@end

@interface TileView : UIView

@property(nonatomic, assign) NSInteger value;
@property(nonatomic, assign, getter = isReadOnly) BOOL readOnly;
@property(nonatomic, retain) id<TileViewDelegate> delegate;

@end
