//
//  GameViewController.m
//  Sudoku
//
//  Created by Warren Moore on 2/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "GameViewController.h"
#import "TileView.h"

@interface GameViewController ()

@property(nonatomic, retain) NSMutableArray *tiles;
@property(nonatomic, retain) NSMutableArray *values;

@end

@implementation GameViewController

@synthesize tiles;
@synthesize values;
@synthesize gridView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
		[self initializePuzzle];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

	CGPoint origin = CGPointMake(0, 0);
	NSInteger i = 0;
	for(int r = 0; r < 9; ++r)
	{
		for(int c = 0; c < 9; ++c, ++i)
		{
			TileView *tile = [[TileView alloc] initWithFrame:CGRectMake(origin.x, origin.y, 32, 32)];
			[self.tiles addObject:tile];
			[self.gridView addSubview:tile];
			[tile setDelegate:self];
			[tile setValue:[[self.values objectAtIndex:i] intValue]];
			if(tile.value != 0)
				[tile setReadOnly:YES];
			
			origin.x += 36;
		}
		
		origin.x = 0;
		origin.y += 36;
	}
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)initializePuzzle {
	NSString *puzzlePath = [[NSBundle mainBundle] pathForResource:@"puzzle" ofType:@"plist"];
	NSDictionary *puzzleInfo = [[NSDictionary alloc] initWithContentsOfFile:puzzlePath];
	self.values = [[puzzleInfo valueForKey:@"values"] mutableCopy];
}

- (void)valueForTileChanged:(TileView *)view {
	NSLog(@"A tile value changed to %d", view.value);
	
	NSInteger tileIndex = [self.tiles indexOfObject:view];
	
	[self.values replaceObjectAtIndex:tileIndex
						   withObject:[NSNumber numberWithInt:view.value]];
}

- (void)updateGameState {
}

@end
