//
//  TileView.m
//  Sudoku
//
//  Created by Warren Moore on 2/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TileView.h"

@interface TileView ()
{
	CGFloat touchBeganY;
}
@end

@implementation TileView

@synthesize value;
@synthesize readOnly;
@synthesize delegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
		self.backgroundColor = [UIColor lightGrayColor];
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
	if(self.value == 0)
		return;
	
	NSString *valueString = [NSString stringWithFormat:@"%d", self.value];
	
	UIFont *font = [UIFont boldSystemFontOfSize:32];
	
	CGContextRef context = UIGraphicsGetCurrentContext();
	if(self.isReadOnly) {
		CGContextSetFillColorWithColor(context, [UIColor blackColor].CGColor);
	} else {
		CGContextSetFillColorWithColor(context, [UIColor darkGrayColor].CGColor);
	}
	
	[valueString drawInRect:rect 
				   withFont:font 
			  lineBreakMode:UILineBreakModeClip 
				  alignment:UITextAlignmentCenter];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
	if([touches count] > 1 || self.isReadOnly)
		return;
	
	CGPoint touchPoint = [[touches anyObject] locationInView:self];
	touchBeganY = touchPoint.y;
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
	if([touches count] > 1 || self.isReadOnly)
		return;
	
	CGPoint touchPoint = [[touches anyObject] locationInView:self];
	CGFloat deltaY = touchBeganY - touchPoint.y;
	
	NSInteger oldValue = self.value;
	
	self.value = deltaY / 15;	
	if(self.value > 9) self.value = 9;
	if(self.value < 0) self.value = 0;
	
	if(self.value != oldValue)
	{
		if([self.delegate respondsToSelector:@selector(valueForTileChanged:)]) {
			[self.delegate valueForTileChanged:self];
		}
	}
	
	[self setNeedsDisplay];
}

@end
