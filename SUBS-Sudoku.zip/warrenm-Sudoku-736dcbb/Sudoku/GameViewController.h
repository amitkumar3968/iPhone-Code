//
//  GameViewController.h
//  Sudoku
//
//  Created by Warren Moore on 2/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GridView.h"
#import "TileView.h"

@interface GameViewController : UIViewController <TileViewDelegate>

@property(nonatomic, retain) IBOutlet GridView *gridView;

@end
